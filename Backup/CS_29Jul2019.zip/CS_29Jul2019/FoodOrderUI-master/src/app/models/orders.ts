import { OrderItem } from './order-item';
export class Orders {
    public OrderID:string;
    public EmailID:string;
    public OrderDateTime:string;
    public RestaurantName:string;
    public OrderStatus:string;
    public DeliveryAddress:string;
    public BillAmount:number;
    public PaymentMode:string;
    public OrderItem:OrderItem[];
}
