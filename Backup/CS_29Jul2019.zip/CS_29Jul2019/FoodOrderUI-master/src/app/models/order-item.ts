export class OrderItem {
    ItemName:string;
    Price:number;
}
