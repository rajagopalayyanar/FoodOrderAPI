import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,of } from 'rxjs';
import { catchError, map, tap, } from 'rxjs/operators';
import { Order } from '../models/order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private http: HttpClient;
  private readonly ordApiUrl:string = 'http://localhost:49983/api/order';

  constructor(_http: HttpClient) {
    this.http=_http;
   }
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  getOrders (): Observable<Order[]> {
    return this.http.get<Order[]>(this.ordApiUrl);
      // .pipe(
      //   tap(items => console.log(`${items['result'].length} items fetched`)),
      //   catchError(this.handleError('getHeroes', []))
      // );
  }
}
