import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../services/order.service'
import { Orders } from 'src/app/models/orders';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {

  public orders : Orders[];
  constructor(private ordService:OrderService) { }

  ngOnInit() {
    this.getOrders();
    console.log(this.orders);
  }
  getOrders(){
    return this.ordService.getOrders()
    .subscribe(ords => {
      this.orders = ords['result'].map(ord => {
        return {
          ...ord
        } 
      }) 
    });
    
  }
}
