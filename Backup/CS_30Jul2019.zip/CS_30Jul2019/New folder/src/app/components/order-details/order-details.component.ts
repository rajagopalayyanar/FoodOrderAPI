import { Component, OnInit } from '@angular/core';
import { Orders } from 'src/app/models/orders';
import { OrdItems } from 'src/app/models/ord-items';
import { OrderService } from '../../services/order.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
  private id:string;
  public ordDetails:Orders;
  public item:string[];
  public ordItem:OrdItems[];
  public selectedItem:string;
  constructor(private route:ActivatedRoute,private ordService:OrderService) { 
    this.id = this.route.snapshot.params["id"];
  }

  ngOnInit() {
    
    this.ordService.getOrder(this.id).subscribe(
      (x)=> {
        this.ordDetails = x;
        this.item = [...new Set(this.ordDetails.orderItems.map(x=>x.ItemName))];
        console.log(console.log(`${this.id} selectedItem`));
        console.log(console.log(`${this.ordDetails} selecte`));
        this.ordItem = this.ordDetails.orderItems.filter(x=>x.ItemName==this.item[0]);
        this.selectedItem = this.item[0];
        
      }
    );
  }
  orderItemclick(m){
    this.selectedItem =m;
    this.ordItem = this.ordDetails.orderItems.filter(x=>x.ItemName==m);
     
  }
  
}
