import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../services/order.service'
import { Orders } from 'src/app/models/orders';
import { Observable } from 'rxjs';
import { Order } from 'src/app/models/order';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {

  public orders : Observable<Order[]>
  public selOrder: Order;
  //public orders : Object[];
  constructor(private router:Router,private ordService:OrderService) {
    //this.orders=[]
   }

  ngOnInit() {
    this.getOrders();
    console.log(this.orders);
  }
  getOrders(){
    this.orders=this.ordService.getOrders();
    /* .subscribe(ords => {
      this.orders = ords['result'].map(ord => {
        return {
          ...ord
        } 
      })  */
    //});
    
  }
  public selectOrder(order){
    this.selOrder = order;
  }
  gotoOrder(id:string){
    this.router.navigate(['/orders',id]);
  }
}
