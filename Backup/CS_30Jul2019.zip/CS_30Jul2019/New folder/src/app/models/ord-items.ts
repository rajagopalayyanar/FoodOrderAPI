export class OrdItems {
    public ItemName:string
    public Price:number
}
