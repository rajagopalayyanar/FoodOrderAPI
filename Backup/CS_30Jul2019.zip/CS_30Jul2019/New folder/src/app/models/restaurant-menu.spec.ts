import { RestaurantMenu } from './restaurant-menu';

describe('RestaurantMenu', () => {
  it('should create an instance', () => {
    expect(new RestaurantMenu()).toBeTruthy();
  });
});
