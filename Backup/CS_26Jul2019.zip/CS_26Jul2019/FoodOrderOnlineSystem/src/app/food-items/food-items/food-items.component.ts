import { Component, OnInit } from '@angular/core';
import { FoodItemsService } from '../../services/food-items.service';
import { Items } from '../../models/items';
@Component({
  selector: 'app-food-items',
  templateUrl: './food-items.component.html',
  styleUrls: ['./food-items.component.css']
})
export class FoodItemsComponent implements OnInit {
  items:Items[];
  constructor(private fooditemsService:FoodItemsService) { }

  ngOnInit() {
    this.getItems();
  }
  getItems(){
    return this.fooditemsService.getItems()
      .subscribe(foodItems=>{
        this.items=foodItems['result'].map(item=>{
          return{
            item, qty:0
          }
        })
      });
  }
}
